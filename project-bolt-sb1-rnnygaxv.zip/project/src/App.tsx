import React from 'react';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { HomeSection } from './components/home/HomeSection';
import { CategoryCard } from './components/home/CategoryCard';

const sections = [
  {
    title: "Petits prix sur les appareils avec Alexa",
    categories: [
      {
        title: "Echo Dot",
        image: "https://images.unsplash.com/photo-1544428571-c69140c5c233?auto=format&fit=crop&q=80&w=400",
        link: "/category/echo-dot"
      },
      {
        title: "Echo Show",
        image: "https://images.unsplash.com/photo-1518444065439-e933c06ce9cd?auto=format&fit=crop&q=80&w=400",
        link: "/category/echo-show"
      },
      {
        title: "Fire TV",
        image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?auto=format&fit=crop&q=80&w=400",
        link: "/category/fire-tv"
      }
    ]
  },
  {
    title: "Aménagez votre maison",
    categories: [
      {
        title: "Meubles",
        image: "https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&q=80&w=400",
        link: "/category/meubles"
      },
      {
        title: "Décoration",
        image: "https://images.unsplash.com/photo-1513519245088-0e12902e35a6?auto=format&fit=crop&q=80&w=400",
        link: "/category/decoration"
      },
      {
        title: "Luminaires",
        image: "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&q=80&w=400",
        link: "/category/luminaires"
      }
    ]
  },
  {
    title: "Cuisine et maison",
    categories: [
      {
        title: "Électroménager",
        image: "https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&q=80&w=400",
        link: "/category/electromenager"
      },
      {
        title: "Ustensiles",
        image: "https://images.unsplash.com/photo-1590794056226-79ef3a8147e1?auto=format&fit=crop&q=80&w=400",
        link: "/category/ustensiles"
      },
      {
        title: "Arts de la table",
        image: "https://images.unsplash.com/photo-1603199506016-b9a594b593c0?auto=format&fit=crop&q=80&w=400",
        link: "/category/arts-table"
      }
    ]
  },
  {
    title: "High-Tech",
    categories: [
      {
        title: "Smartphones",
        image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&q=80&w=400",
        link: "/category/smartphones"
      },
      {
        title: "Ordinateurs",
        image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&q=80&w=400",
        link: "/category/ordinateurs"
      },
      {
        title: "Accessoires",
        image: "https://images.unsplash.com/photo-1625886390251-01af5c989f54?auto=format&fit=crop&q=80&w=400",
        link: "/category/accessoires"
      }
    ]
  }
];

function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <section className="mb-12">
            <div className="relative h-[400px] rounded-2xl overflow-hidden mb-8">
              <img 
                src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&q=80&w=2000"
                alt="Hero" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent flex items-center">
                <div className="text-white p-12">
                  <h1 className="text-5xl font-bold mb-4">Bienvenue chez Inovia</h1>
                  <p className="text-xl mb-8">Découvrez notre sélection de produits premium pour votre maison</p>
                  <button className="bg-indigo-600 text-white px-8 py-3 rounded-lg hover:bg-indigo-700 transition-colors">
                    Découvrir
                  </button>
                </div>
              </div>
            </div>
          </section>

          {sections.map((section, index) => (
            <HomeSection key={index} title={section.title}>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {section.categories.map((category, categoryIndex) => (
                  <CategoryCard
                    key={categoryIndex}
                    title={category.title}
                    image={category.image}
                    link={category.link}
                  />
                ))}
              </div>
            </HomeSection>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
}

export default App;