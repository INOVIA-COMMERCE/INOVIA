import React from 'react';

interface CategoryCardProps {
  title: string;
  image: string;
  link: string;
}

export function CategoryCard({ title, image, link }: CategoryCardProps) {
  return (
    <a 
      href={link}
      className="group block relative rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300"
    >
      <div className="aspect-w-16 aspect-h-9">
        <img 
          src={image} 
          alt={title}
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-300"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
        <h3 className="text-white text-xl font-semibold p-6 w-full">
          {title}
        </h3>
      </div>
    </a>
  );
}