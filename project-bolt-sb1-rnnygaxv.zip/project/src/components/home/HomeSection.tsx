import React from 'react';

interface HomeSectionProps {
  title: string;
  children: React.ReactNode;
}

export function HomeSection({ title, children }: HomeSectionProps) {
  return (
    <section className="mb-16">
      <h2 className="text-2xl font-bold text-gray-900 mb-8">{title}</h2>
      {children}
    </section>
  );
}