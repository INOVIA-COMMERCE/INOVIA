import React from 'react';
import { Package, CreditCard, CheckCircle } from 'lucide-react';

export function AboutPage() {
  const steps = [
    {
      icon: <Package className="h-12 w-12 text-indigo-600" />,
      title: "Vendre un produit",
      description: "Lorsqu'un vendeur souhaite vendre un produit, il le publie sur la plateforme Inovia. Les acheteurs peuvent alors consulter et acheter ces produits."
    },
    {
      icon: <CreditCard className="h-12 w-12 text-indigo-600" />,
      title: "Payer un produit",
      description: "Quand un client clique sur \"Payer\" pour acheter un produit, l'argent est automatiquement envoyé dans le système d'Inovia."
    },
    {
      icon: <CheckCircle className="h-12 w-12 text-indigo-600" />,
      title: "Recevoir le colis",
      description: "Une fois que le client a reçu le colis, il clique sur le bouton \"Colis reçu\". À ce moment-là, le système transfère automatiquement l'argent du client vers le compte du vendeur."
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">À propos d'Inovia</h1>
          <p className="text-xl text-gray-600 mb-12">
            Inovia est une application de vente en ligne qui facilite les transactions entre les vendeurs et les acheteurs.
          </p>
        </div>

        <div className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">Comment ça fonctionne</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-8">
                <div className="flex justify-center mb-6">
                  {step.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">
                  {step.title}
                </h3>
                <p className="text-gray-600 text-center">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="bg-white rounded-lg shadow-md p-8">
            <p className="text-lg text-gray-600">
              Inovia offre une expérience d'achat et de vente en ligne sécurisée et fiable, en assurant la protection des transactions pour les deux parties.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}