import React, { useState } from 'react';
import { ShoppingCart, User, Menu, X } from 'lucide-react';

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navigationItems = [
    { name: 'Toutes', href: '/categories' },
    { name: 'Meilleures ventes', href: '/best-sellers' },
    { name: 'Inovia Basics', href: '/inovia-basics' },
    { name: 'Ventes Flash', href: '/flash-sales' },
    { name: 'Dernières Nouveautés', href: '/new-arrivals' },
    { name: 'Vendre sur Inovia', href: '/sell' },
    { name: 'Idées cadeaux', href: '/gift-ideas' },
    { name: 'Livres', href: '/books' },
    { name: "Guide de l'acheteur", href: '/buyers-guide' },
    { name: 'À propos', href: '/about' },
  ];

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main navigation bar */}
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <a href="/" className="text-2xl font-bold text-indigo-600">Inovia</a>
          </div>

          <div className="flex items-center space-x-4">
            <button className="text-gray-700 hover:text-indigo-600">
              <ShoppingCart className="h-6 w-6" />
            </button>
            <button className="text-gray-700 hover:text-indigo-600">
              <User className="h-6 w-6" />
            </button>
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="sm:hidden text-gray-700 hover:text-indigo-600"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>

        {/* Categories navigation */}
        <div className="hidden sm:block border-t">
          <div className="flex space-x-8 py-3 -mb-px overflow-x-auto">
            {navigationItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="text-gray-700 hover:text-indigo-600 whitespace-nowrap text-sm font-medium"
              >
                {item.name}
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`sm:hidden ${isMenuOpen ? 'block' : 'hidden'}`}>
        <div className="px-2 pt-2 pb-3 space-y-1 bg-white border-t">
          {navigationItems.map((item) => (
            <a
              key={item.name}
              href={item.href}
              className="block px-3 py-2 text-base font-medium text-gray-700 hover:text-indigo-600 hover:bg-gray-50 rounded-md"
            >
              {item.name}
            </a>
          ))}
        </div>
      </div>
    </nav>
  );
}